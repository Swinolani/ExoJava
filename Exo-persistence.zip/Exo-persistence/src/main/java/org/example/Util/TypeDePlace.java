package org.example.Util;

public enum TypeDePlace {
    STANDARD,
    GOLD,
    VIP
}
